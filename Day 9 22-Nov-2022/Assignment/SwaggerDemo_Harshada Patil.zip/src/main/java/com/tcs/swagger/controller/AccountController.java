package com.tcs.swagger.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AccountController {
	@RequestMapping("/accounts")
	public String hello() {
		return "Welocome to Swagger accounts";
	}
}



	