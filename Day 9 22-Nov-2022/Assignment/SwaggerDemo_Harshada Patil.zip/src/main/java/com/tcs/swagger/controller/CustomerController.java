package com.tcs.swagger.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CustomerController {
	@RequestMapping("/customers")
	public String hello() {
		return "Welocome to Swagger customers";
	}


}
