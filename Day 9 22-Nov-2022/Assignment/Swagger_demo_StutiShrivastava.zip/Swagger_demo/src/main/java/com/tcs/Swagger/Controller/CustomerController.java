package com.tcs.Swagger.Controller;


import org.springframework.web.bind.annotation.RestController;


@RestController
public class CustomerController {
		
	
}
