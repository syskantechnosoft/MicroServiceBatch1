package com.tcs.monolith.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.tcs.monolith.model.Role;
import com.tcs.monolith.repo.RoleRepository;

public class RoleServiceimpl implements RoleService {

	@Autowired
	RoleRepository roleRepository;
	
	@Override
	public List<Role> getRoles() {
		// TODO Auto-generated method stub
		return roleRepository.findAll();
	}

	@Override
	public Role getRoleById(int id) {
		// TODO Auto-generated method stub
		return roleRepository.findById(id).get();
	}

	@Override
	public void addrole(Role role) {
		// TODO Auto-generated method stub
		roleRepository.save(role);
	}

	@Override
	public void editRole(int id, Role role) {
		// TODO Auto-generated method stub
		roleRepository.save(role);
	}

	@Override
	public void deleteRole(int id) {
		// TODO Auto-generated method stub
		roleRepository.deleteById(id);
	}
	
	

}
