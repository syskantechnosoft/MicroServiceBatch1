package com.tcs.monolith;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day6MonolithApplicationTests {

	@Test
	void contextLoads() {
	}

}
