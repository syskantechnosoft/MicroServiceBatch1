package com.tcs.monolith;
//importing packages
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
//defining class and objects
@SpringBootTest
class Day6monolithApplicationTests {

	@Test
	void contextLoads() {
	}

}
