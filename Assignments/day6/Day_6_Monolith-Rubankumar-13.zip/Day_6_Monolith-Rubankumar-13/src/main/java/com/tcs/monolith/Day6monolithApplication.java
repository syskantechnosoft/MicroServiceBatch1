package com.tcs.monolith;
//importing spring framework
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//springframework class creation
@SpringBootApplication
public class Day6monolithApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day6monolithApplication.class, args);
	}

}
