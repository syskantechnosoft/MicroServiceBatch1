package com.tcs.monolith.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tb1_role")
public class Role {
	@Id
	private int id;
	private String name;
	

}
