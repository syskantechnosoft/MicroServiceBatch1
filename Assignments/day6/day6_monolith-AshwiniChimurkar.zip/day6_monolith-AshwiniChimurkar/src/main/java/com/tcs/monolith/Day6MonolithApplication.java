package com.tcs.monolith;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day6MonolithApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day6MonolithApplication.class, args);
	}

}
