package com.tcs.day6monolith.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tcs.day6monolith.model.User;

public interface UserRepository extends JpaRepository<User, Integer> {

	

}







