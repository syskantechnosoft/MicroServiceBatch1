
package com.tcs.day6monolith.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.tcs.day6monolith.model.Role;

import com.tcs.day6monolith.repo.RoleRepository;
@RestController
public class RoleController
{

	@Autowired
	RoleRepository roleRepository11;
	private CrudRepository<Role, Integer> roleRepository1;
	
	
	@GetMapping("/role")
	public List<Role> getRole(){
		return roleRepository11.findAll();
	}
	
	@GetMapping("/role/{id}")
	public Role getRoleById(@PathVariable int id) {
		//CrudRepository<User, Integer> userRepository;
		return roleRepository11.findById(id).get();
	}
	@PostMapping("/role")
	public void addRole(@RequestBody Role role) {
		roleRepository11.save(role);
		
	}
	
	@DeleteMapping("/role/{id}")
	
		// TODO Auto-generated method stub
      public void deleteRole(@PathVariable int id)
      {
    	   
		roleRepository11 = null;
		roleRepository11.deleteById(id);
        
	}
	
	@PutMapping("/role/{id}")
	public void editRole(@PathVariable int id,@RequestBody Role user) {
		roleRepository1 = null;
		roleRepository1.save(user);
		
	}
	

}
