package com.tcs.day6monolith.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tcs.day6monolith.model.Role;

public interface RoleRepository extends JpaRepository<Role, Integer> {

	

}
