package com.tcs.monolith.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tcs.monolith.model.User;
import com.tcs.monolith.repo.UserRepo;

@Service
public class UserServiceImpl implements UserService{
	
	@Autowired
	UserRepo userrepo;

	@Override
	public List<User> getUsers() {
		// TODO Auto-generated method stub
		return userrepo.findAll();
	}

	@Override
	public User getUserById(int id) {
		// TODO Auto-generated method stub
		
		return userrepo.findById(id).get();
	}

	@Override
	public void addUser(User user) {
		// TODO Auto-generated method stub
		userrepo.save(user);
	}

	@Override
	public void editUser(int id, User user) {
		// TODO Auto-generated method stub
		userrepo.save(user);
	}

	@Override
	public void deleteUser(int id) {
		// TODO Auto-generated method stub
		userrepo.deleteById(id);
		
	}

}
