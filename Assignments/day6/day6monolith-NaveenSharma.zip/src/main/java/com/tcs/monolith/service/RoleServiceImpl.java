package com.tcs.monolith.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tcs.monolith.model.Role;
import com.tcs.monolith.repo.RoleRepo;

@Service
public class RoleServiceImpl implements RoleService {

	
	@Autowired
	RoleRepo rolerepo;
	
	
	@Override
	public List<Role> getAllRoles() {
		// TODO Auto-generated method stub
		return rolerepo.findAll() ;
	}

	@Override
	public Role getRoleById(int id) {
		// TODO Auto-generated method stub
		return rolerepo.findById(id).get();
	}

	@Override
	public void addRole(Role role) {
		// TODO Auto-generated method stub
		rolerepo.save(role);
		
	}

	@Override
	public void editRole(int id, Role role) {
		// TODO Auto-generated method stub
		rolerepo.save(role);
	}

	@Override
	public void deleteRole(int id) {
		// TODO Auto-generated method stub
		rolerepo.deleteById(id);
		
	}

}
