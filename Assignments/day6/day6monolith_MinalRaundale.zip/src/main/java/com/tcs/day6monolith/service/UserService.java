package com.tcs.day6monolith.service;

import java.util.List;

import com.tcs.day6monolith.model.User;

public interface UserService {

	List<User> getUSers();

	User getUserById(int id);

	void addUser(User user);

	void editUser(int id, User user);

	void deleteUser(int id);

}
