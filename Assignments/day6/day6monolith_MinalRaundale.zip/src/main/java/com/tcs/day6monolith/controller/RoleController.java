package com.tcs.day6monolith.controller;

public class RoleController {

}
