//Day6monolithApplication.java class
package com.tcs.monolith;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day6monolithApplication {
	public static void main(String[] args) {
		SpringApplication.run(Day6monolithApplication.class, args);
	}
}
