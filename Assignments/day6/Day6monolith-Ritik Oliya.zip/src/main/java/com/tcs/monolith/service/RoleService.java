package com.tcs.monolith.service;

import java.util.List;
import com.tcs.monolith.model.Role;

public interface RoleService {
	public List<Role> getRoles();
	public Role getRoleById(int id);
	public void addRole(Role role);
	public void editRole(int id,Role role);
	public void deleteRole(int id);
}